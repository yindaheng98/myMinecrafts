package buildcraft.api.transport.pipe_bc8;

public interface IPipeHolder_BC8 {
    IPipe_BC8 getPipe();
}
