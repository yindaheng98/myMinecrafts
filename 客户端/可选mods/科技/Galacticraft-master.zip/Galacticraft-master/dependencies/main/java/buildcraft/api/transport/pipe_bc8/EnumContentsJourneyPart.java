package buildcraft.api.transport.pipe_bc8;

public enum EnumContentsJourneyPart {
    JUST_ENTERED,
    TO_CENTER,
    FROM_CENTER;
}
