package codechicken.nei;

public class NEICompatibility {
}
