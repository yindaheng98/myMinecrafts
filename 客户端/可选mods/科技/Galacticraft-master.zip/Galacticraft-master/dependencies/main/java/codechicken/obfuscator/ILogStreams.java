package codechicken.obfuscator;

import java.io.PrintStream;

public interface ILogStreams {
    public PrintStream err();

    public PrintStream out();
}
