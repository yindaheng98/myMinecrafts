package codechicken.nei.guihook;

/**
 * Marker interface. If detected, slot clicks will be sent only to the client side container and not to the server
 */
public interface IGuiClientSide {
}
