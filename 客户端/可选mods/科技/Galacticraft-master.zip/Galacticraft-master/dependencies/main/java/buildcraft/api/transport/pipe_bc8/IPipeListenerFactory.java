package buildcraft.api.transport.pipe_bc8;

public interface IPipeListenerFactory {
    IPipeListener createNewListener(IPipe_BC8 pipe);
}
