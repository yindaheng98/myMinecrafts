package codechicken.nei.api;

public interface INEIModeHandler {
    public boolean isModeValid(int mode);
}
