package codechicken.core;

public interface IStringMatcher {
    public boolean matches(String test);
}
