package buildcraft.api.transport.pluggable;

public interface IPipeRenderState {
    IConnectionMatrix getPipeConnectionMatrix();
}
